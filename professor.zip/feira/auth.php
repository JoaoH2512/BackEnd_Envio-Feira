<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function professorAtual(): ?array
{
    return isset($_SESSION['professor']) && is_array($_SESSION['professor'])
        ? $_SESSION['professor']
        : null;
}

function exigirProfessor(): array
{
    $professor = professorAtual();
    if (!$professor || empty($professor['id'])) {
        $destino = urlencode($_SERVER['REQUEST_URI'] ?? '/dashboard.php');
        header('Location: login.php?redirect=' . $destino);
        exit;
    }
    return $professor;
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validarCsrf(?string $token): void
{
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        exit('Requisição inválida. Atualize a página e tente novamente.');
    }
}

function redirecionarSeguro(string $fallback = 'dashboard.php'): void
{
    $destino = $_POST['redirect'] ?? $_GET['redirect'] ?? $fallback;
    if (!is_string($destino) || $destino === '' || preg_match('#^(?:https?:)?//#i', $destino)) {
        $destino = $fallback;
    }
    header('Location: ' . $destino);
    exit;
}

function formatarNota(mixed $valor): string
{
    return number_format((float) $valor, 1, ',', '');
}

function slug(string $valor): string
{
    $valor = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $valor) ?: $valor;
    return strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $valor), '-'));
}

function statusProjeto(string $status, ?float $nota = null): array
{
    if ($nota !== null || $status === 'concluido') {
        return ['label' => 'Avaliado', 'class' => 'approved'];
    }
    return ['label' => $status === 'em_andamento' ? 'Em andamento' : 'Pendente', 'class' => 'pending'];
}
?>
