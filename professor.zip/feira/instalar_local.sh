#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DB_NAME="${FEIRA_DB_NAME:-feirabd}"
DB_USER="${FEIRA_DB_USER:-feirabd_app}"
DB_PASS="${FEIRA_DB_PASS:-feira_local_2026}"

if ! command -v mysql >/dev/null 2>&1; then
  echo "MySQL/MariaDB não encontrado. Instale o servidor antes de continuar." >&2
  exit 1
fi

# Cria somente o banco, sem tocar nas tabelas existentes.
sudo mysql -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

has_schema="$(sudo mysql -N -B -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${DB_NAME}' AND table_name='professor';")"
if [[ "${FEIRA_RECREATE_SCHEMA:-0}" == "1" ]]; then
  echo "FEIRA_RECREATE_SCHEMA=1: recriando o schema a partir de FeiraBD.sql."
  sudo mysql < "$ROOT_DIR/FeiraBD.sql"
elif [[ "$has_schema" == "0" ]]; then
  echo "Schema ausente: importando FeiraBD.sql pela primeira vez."
  sudo mysql < "$ROOT_DIR/FeiraBD.sql"
else
  echo "Schema existente preservado; FeiraBD.sql não será importado."
fi

sudo mysql <<SQL
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
ALTER USER '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT SELECT, INSERT, UPDATE, DELETE ON \`${DB_NAME}\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
SQL

if [[ "${FEIRA_SEED_DEMO:-1}" == "1" && -f "$ROOT_DIR/seed-demo.sql" ]]; then
  mysql --protocol=socket -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" < "$ROOT_DIR/seed-demo.sql"
fi

echo "Banco $DB_NAME preparado sem apagar tabelas existentes. Usuário da aplicação: $DB_USER"
if [[ "${FEIRA_RECREATE_SCHEMA:-0}" == "1" ]]; then
  echo "Aviso: o modo de recriação foi solicitado e pode ter substituído dados existentes."
fi
