<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
$professor = exigirProfessor();
require_once __DIR__ . '/conexao.php';

$stmt = $pdo->prepare(
    'SELECT p.id, p.nome, p.descricao, p.status, p.periodo, p.nota,
            a.curso, a.turma, s.num_stand AS estande, s.sala,
            AVG(CASE WHEN av.status = "concluida" THEN av.nota END) AS nota_avaliacao
     FROM projeto p
     LEFT JOIN aluno a ON a.id = p.id_aluno
     LEFT JOIN stands s ON s.fk_projeto = p.id
     LEFT JOIN avaliacao av ON av.projeto_id = p.id
     WHERE p.orientador_id = :professor_id
     GROUP BY p.id, p.nome, p.descricao, p.status, p.periodo, p.nota,
              a.curso, a.turma, s.num_stand, s.sala
     ORDER BY p.id DESC'
);
$stmt->execute(['professor_id' => $professor['id']]);
$projetos = $stmt->fetchAll();

$avaliados = 0;
$somaNotas = 0.0;
foreach ($projetos as &$projeto) {
    $projeto['nota_final'] = $projeto['nota_avaliacao'] !== null ? (float) $projeto['nota_avaliacao'] : ($projeto['nota'] !== null ? (float) $projeto['nota'] : null);
    if ($projeto['nota_final'] !== null || $projeto['status'] === 'concluido') {
        $avaliados++;
        if ($projeto['nota_final'] !== null) $somaNotas += $projeto['nota_final'];
    }
    $projeto['status_ui'] = statusProjeto((string) $projeto['status'], $projeto['nota_final']);
}
unset($projeto);
$pendentes = count($projetos) - $avaliados;
$media = $avaliados > 0 ? $somaNotas / $avaliados : 0;
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="theme-color" content="#7a0714">
  <title>Dashboard | Feira Tecnológica</title><link rel="stylesheet" href="style.css">
</head>
<body data-page="dashboard">
<main class="portal">
  <aside class="sidebar" aria-label="Navegação da área do professor">
    <a class="brand-lockup" href="dashboard.php" aria-label="Feira Tecnológica — página inicial"><span class="brand-emblem">MCM</span><span class="brand-copy"><strong>Feira Tecnológica</strong><span>ETEC Maria Cristina Medeiros</span></span></a>
    <p class="sidebar-label">Área do Professor</p>
    <nav class="side-nav" aria-label="Navegação principal">
      <button class="active" type="button" data-page="dashboard.php">▣ Avaliações Gerais</button>
      <button type="button" data-page="trabalhos.php">▤ Trabalhos Orientados</button>
      <button type="button" data-page="avisos.php">♧ Avisos</button>
      <button type="button" data-page="fale-conosco.php">✉ Fale conosco</button>
      <button type="button" data-page="perfil.php">◯ Perfil</button>
    </nav><p class="sidebar-footer">Feira Tecnológica · 2026</p>
  </aside>
  <section class="content-column">
    <header class="topbar"><div><p class="eyebrow">PAINEL DO PROFESSOR</p><h1>Bem-vindo, <?= e($professor['nome']) ?></h1><p>Confira o panorama dos projetos sob sua orientação.</p></div><button class="notification-button" type="button" data-notification="Você não possui novos avisos." aria-label="Ver avisos">♧</button></header>
    <section class="metrics" aria-label="Resumo geral">
      <article class="metric-card metric-wine"><span class="metric-line"></span><p>Projetos orientados</p><strong><?= count($projetos) ?></strong><small>Total cadastrado</small></article>
      <article class="metric-card metric-gold"><span class="metric-line"></span><p>Avaliações pendentes</p><strong><?= $pendentes ?></strong><small>Aguardando conclusão</small></article>
      <article class="metric-card metric-blue"><span class="metric-line"></span><p>Avaliações concluídas</p><strong><?= $avaliados ?></strong><small>Registradas no banco</small></article>
      <article class="metric-card metric-green"><span class="metric-line"></span><p>Média das notas finais</p><strong><?= $avaliados ? number_format($media, 2, ',', '') : '—' ?></strong><small>Projetos avaliados</small></article>
    </section>
    <section aria-labelledby="projects-title"><div class="section-heading"><h2 id="projects-title">Projetos Orientados</h2><button class="text-action" type="button" data-page="trabalhos.php">Ver todos</button></div>
      <div class="project-list"><table class="project-table"><caption class="screen-reader-only">Projetos acompanhados por <?= e($professor['nome']) ?></caption><thead><tr><th>Projeto</th><th>Curso</th><th>Turma</th><th>Estande</th><th>Status</th><th>Visualização</th><th>Edição</th></tr></thead><tbody>
      <?php if (!$projetos): ?><tr><td colspan="7" class="empty-state">Nenhum projeto está vinculado a este professor.</td></tr><?php endif; ?>
      <?php foreach ($projetos as $projeto): ?><tr><td class="project-name"><?= e($projeto['nome']) ?></td><td><?= e($projeto['curso'] ?? '—') ?></td><td><?= e($projeto['turma'] ?? '—') ?></td><td><?= e($projeto['estande'] ?? '—') ?></td><td><span class="status <?= e($projeto['status_ui']['class']) ?>"><?= e($projeto['status_ui']['label']) ?></span></td><td><a class="icon-button" href="popupolho.php?projeto=<?= (int) $projeto['id'] ?>" aria-label="Ver projeto <?= e($projeto['nome']) ?>">◉</a></td><td><a class="icon-button" href="avaliacao.php?projeto=<?= (int) $projeto['id'] ?>" aria-label="Editar avaliação de <?= e($projeto['nome']) ?>">✎</a></td></tr><?php endforeach; ?>
      </tbody></table></div>
    </section>
  </section>
  <nav class="mobile-nav" aria-label="Navegação móvel"><button class="active" type="button" data-page="dashboard.php">▣<span>Avaliações</span></button><button type="button" data-page="trabalhos.php">▤<span>Orientados</span></button><button type="button" data-page="avisos.php">♧<span>Avisos</span></button><button type="button" data-page="fale-conosco.php">✉<span>Contato</span></button><button type="button" data-page="perfil.php">◯<span>Perfil</span></button></nav>
</main><script src="script.js"></script>
</body></html>
