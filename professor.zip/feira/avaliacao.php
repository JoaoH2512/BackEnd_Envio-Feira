<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
$professor = exigirProfessor();
require_once __DIR__ . '/conexao.php';
$projetoId = (int) ($_GET['projeto'] ?? $_POST['projeto_id'] ?? 0);
if ($projetoId < 1) { header('Location: dashboard.php'); exit; }

$projetoStmt = $pdo->prepare('SELECT p.id, p.nome, p.descricao, p.status, p.nota, a.curso, a.turma, s.num_stand AS estande FROM projeto p LEFT JOIN aluno a ON a.id=p.id_aluno LEFT JOIN stands s ON s.fk_projeto=p.id WHERE p.id=:id AND p.orientador_id=:professor_id LIMIT 1');
$projetoStmt->execute(['id' => $projetoId, 'professor_id' => $professor['id']]);
$projeto = $projetoStmt->fetch();
if (!$projeto) { http_response_code(404); exit('Projeto não encontrado ou sem permissão.'); }

$criterios = $pdo->query('SELECT id, nome FROM criterio ORDER BY id')->fetchAll();
$avaliacoes = [];
$notasStmt = $pdo->prepare('SELECT criterio_id, nota, observacao FROM avaliacao WHERE avaliador_id=:avaliador_id AND projeto_id=:projeto_id');
$notasStmt->execute(['avaliador_id' => $professor['id'], 'projeto_id' => $projetoId]);
foreach ($notasStmt as $row) $avaliacoes[(int) $row['criterio_id']] = $row;
$mensagem = '';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validarCsrf($_POST['csrf_token'] ?? null);
    $notas = is_array($_POST['notas'] ?? null) ? $_POST['notas'] : [];
    $observacao = trim((string) ($_POST['observacao'] ?? ''));
    $valores = [];
    foreach ($criterios as $criterio) {
        $id = (int) $criterio['id'];
        $nota = str_replace(',', '.', (string) ($notas[$id] ?? ''));
        if ($nota === '' || !is_numeric($nota) || (float) $nota < 0 || (float) $nota > 10) { $erro = 'Preencha todas as notas entre 0 e 10.'; break; }
        $valores[$id] = round((float) $nota * 2) / 2;
    }
    if (!$erro && $criterios) {
        try {
            $pdo->beginTransaction();
            $upsert = $pdo->prepare('INSERT INTO avaliacao (avaliador_id, projeto_id, criterio_id, nota, status, observacao) VALUES (:avaliador_id, :projeto_id, :criterio_id, :nota, "concluida", :observacao) ON DUPLICATE KEY UPDATE nota=VALUES(nota), status="concluida", observacao=VALUES(observacao)');
            foreach ($valores as $criterioId => $nota) $upsert->execute(['avaliador_id'=>$professor['id'], 'projeto_id'=>$projetoId, 'criterio_id'=>$criterioId, 'nota'=>$nota, 'observacao'=>$observacao]);
            $mediaStmt = $pdo->prepare('SELECT AVG(nota) FROM avaliacao WHERE projeto_id=:projeto_id AND status="concluida"');
            $mediaStmt->execute(['projeto_id'=>$projetoId]);
            $media = $mediaStmt->fetchColumn();
            $updateProjeto = $pdo->prepare('UPDATE projeto SET nota=:nota, status="concluido" WHERE id=:id');
            $updateProjeto->execute(['nota'=>$media, 'id'=>$projetoId]);
            $pdo->commit();
            $mensagem = 'Avaliação salva com sucesso.';
            $projeto['nota'] = $media;
            foreach ($valores as $id => $nota) $avaliacoes[$id] = ['nota'=>$nota, 'observacao'=>$observacao];
        } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $erro = 'Não foi possível salvar a avaliação.'; }
    } elseif (!$criterios) { $erro = 'Nenhum critério de avaliação foi cadastrado.'; }
}
$observacaoAtual = '';
foreach ($avaliacoes as $av) if (!empty($av['observacao'])) { $observacaoAtual = $av['observacao']; break; }
?>
<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="theme-color" content="#7a0714"><title>Avaliação | Feira Tecnológica</title><link rel="stylesheet" href="style.css"></head>
<body><main class="portal"><aside class="sidebar"><a class="brand-lockup" href="dashboard.php"><span class="brand-emblem">MCM</span><span class="brand-copy"><strong>Feira Tecnológica</strong><span>ETEC Maria Cristina Medeiros</span></span></a><p class="sidebar-label">Área do Professor</p><nav class="side-nav"><button class="active" type="button" data-page="dashboard.php">▣ Avaliações Gerais</button><button type="button" data-page="trabalhos.php">▤ Trabalhos Orientados</button><button type="button" data-page="avisos.php">♧ Avisos</button><button type="button" data-page="fale-conosco.php">✉ Fale conosco</button><button type="button" data-page="perfil.php">◯ Perfil</button></nav></aside><section class="content-column"><a class="back-link" href="dashboard.php">← Voltar</a><header class="topbar"><div><p class="eyebrow">AVALIAÇÕES GERAIS</p><h1><?= e($projeto['nome']) ?></h1><p>Revise as informações para concluir a avaliação do projeto.</p></div></header><section class="evaluation-grid"><article class="evaluation-card"><div class="project-ident"><span class="round-project-icon">▣</span><div><h2><?= e($projeto['nome']) ?></h2><p><?= e($projeto['estande'] ? 'Estande ' . $projeto['estande'] . ' · ' : '') ?><?= e($projeto['curso'] ?? '') ?> <?= e($projeto['turma'] ?? '') ?></p></div></div><div class="evaluation-section"><h3>Descrição do projeto</h3><p><?= e($projeto['descricao'] ?? 'Sem descrição cadastrada.') ?></p></div><form method="post" class="evaluation-form"><input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>"><input type="hidden" name="projeto_id" value="<?= $projetoId ?>"><div class="evaluation-section"><h3>Critérios de avaliação</h3><?php foreach ($criterios as $criterio): $id=(int)$criterio['id']; $nota=$avaliacoes[$id]['nota'] ?? ''; ?><div class="criterion"><div class="criterion-copy"><h3><?= e($criterio['nome']) ?></h3><p>Informe uma nota entre 0 e 10.</p></div><div class="score-control"><input class="score-range" type="range" min="0" max="10" step="0.5" value="<?= e($nota === '' ? 0 : $nota) ?>" oninput="this.nextElementSibling.value=this.value"><input class="score-input" name="notas[<?= $id ?>]" type="number" min="0" max="10" step="0.5" value="<?= e($nota) ?>" required></div></div><?php endforeach; ?></div><div class="evaluation-section"><h3>Comentários do avaliador</h3><textarea class="comment-box" name="observacao" maxlength="800" placeholder="Descreva os principais pontos observados."><?= e($observacaoAtual) ?></textarea></div><?php if ($mensagem): ?><p id="form-status" role="status"><?= e($mensagem) ?></p><?php endif; ?><?php if ($erro): ?><p class="login-error" role="alert"><?= e($erro) ?></p><?php endif; ?><div class="form-actions"><button class="compact-button" type="submit">Salvar avaliação</button><a class="secondary-button" href="dashboard.php">Cancelar</a></div></form></article><aside class="evaluation-aside"><article class="aside-card"><h3>Resumo da avaliação</h3><dl class="summary-list"><div><dt>Curso</dt><dd><?= e($projeto['curso'] ?? '—') ?></dd></div><div><dt>Turma</dt><dd><?= e($projeto['turma'] ?? '—') ?></dd></div><div><dt>Nota</dt><dd><?= $projeto['nota'] !== null ? e(formatarNota($projeto['nota'])) : '—' ?></dd></div></dl></article></aside></section></section><nav class="mobile-nav"><button class="active" type="button" data-page="dashboard.php">▣<span>Avaliações</span></button><button type="button" data-page="trabalhos.php">▤<span>Orientados</span></button><button type="button" data-page="avisos.php">♧<span>Avisos</span></button><button type="button" data-page="fale-conosco.php">✉<span>Contato</span></button><button type="button" data-page="perfil.php">◯<span>Perfil</span></button></nav></main><script src="script.js"></script></body></html>
