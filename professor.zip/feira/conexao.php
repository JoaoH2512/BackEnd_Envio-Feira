<?php
declare(strict_types=1);

$host = getenv('FEIRA_DB_HOST') ?: 'localhost';
$db   = getenv('FEIRA_DB_NAME') ?: 'feirabd';
$user = getenv('FEIRA_DB_USER') ?: 'feirabd_app';
$pass = getenv('FEIRA_DB_PASS') ?: 'feira_local_2026';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    error_log('Falha de conexão com o banco da Feira: ' . $e->getMessage());
    http_response_code(503);
    exit('Não foi possível conectar ao sistema no momento.');
}
?>
