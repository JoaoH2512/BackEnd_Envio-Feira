<?php
require_once __DIR__ . '/../conexao.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: admin.php'); exit; }
$nome = trim((string)($_POST['nome'] ?? ''));
$matricula = trim((string)($_POST['matricula'] ?? $_POST['rm'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$senha = (string)($_POST['senha'] ?? '');
if ($nome === '' || $matricula === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $senha === '') { header('Location: admin.php?erro=dados'); exit; }
$stmt = $pdo->prepare('INSERT INTO professor (nome, matricula, email, senha, tipo) VALUES (:nome, :matricula, :email, :senha, "avaliador")');
$stmt->execute(['nome'=>$nome, 'matricula'=>$matricula, 'email'=>$email, 'senha'=>password_hash($senha, PASSWORD_DEFAULT)]);
header('Location: admin.php'); exit;
?>
