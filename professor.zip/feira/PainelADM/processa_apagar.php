<?php
require_once __DIR__ . '/../conexao.php';
header('Content-Type: application/json; charset=utf-8');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); echo json_encode(['sucesso' => false, 'erro' => 'ID não informado']); exit; }
$stmt = $pdo->prepare('DELETE FROM professor WHERE id = :id');
$stmt->execute(['id' => $id]);
echo json_encode(['sucesso' => $stmt->rowCount() > 0]);
?>
