<?php
require_once __DIR__ . '/../conexao.php';
header('Content-Type: application/json; charset=utf-8');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); echo json_encode(['erro' => 'ID não informado']); exit; }
$stmt = $pdo->prepare('SELECT id, nome, matricula AS ra, email, tipo FROM professor WHERE id = :id');
$stmt->execute(['id' => $id]);
echo json_encode($stmt->fetch() ?: null, JSON_UNESCAPED_UNICODE);
?>
