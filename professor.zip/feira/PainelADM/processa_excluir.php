<?php
require_once __DIR__ . '/../conexao.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($id) { $stmt = $pdo->prepare('DELETE FROM professor WHERE id = :id'); $stmt->execute(['id' => $id]); }
header('Location: admin.php');
exit;
?>
