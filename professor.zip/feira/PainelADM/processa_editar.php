<?php
require_once __DIR__ . '/../conexao.php';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['sucesso' => false, 'erro' => 'Método inválido']); exit; }
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$nome = trim((string)($_POST['nome'] ?? ''));
$matricula = trim((string)($_POST['matricula'] ?? $_POST['rm'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
if (!$id || $nome === '' || $matricula === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) { http_response_code(422); echo json_encode(['sucesso' => false, 'erro' => 'Dados inválidos']); exit; }
$stmt = $pdo->prepare('UPDATE professor SET nome=:nome, matricula=:matricula, email=:email WHERE id=:id');
$stmt->execute(['nome'=>$nome, 'matricula'=>$matricula, 'email'=>$email, 'id'=>$id]);
echo json_encode(['sucesso' => true]);
?>
