# Backend da Feira Tecnológica

Backend PHP integrado ao frontend do Portal do Professor. A aplicação usa as tabelas já existentes do banco `feirabd` e não executa migrations nem alterações de schema.

## Entradas principais

| Tela | Rota |
| --- | --- |
| Login | `login.php` |
| Dashboard | `dashboard.php` |
| Trabalhos orientados | `trabalhos.php` |
| Avaliação | `avaliacao.php?projeto=ID` |
| Avisos | `avisos.php` |
| Perfil | `perfil.php` |
| Logout | `logout.php` |

## Configuração

Por padrão, a conexão usa `localhost`, banco `feirabd`, usuário `feirabd_app` e senha `feira_local_2026`. Em produção, defina `FEIRA_DB_HOST`, `FEIRA_DB_NAME`, `FEIRA_DB_USER` e `FEIRA_DB_PASS` como variáveis de ambiente e não use as credenciais locais.

Para preparar uma instalação local com MariaDB/MySQL, execute `chmod +x instalar_local.sh && ./instalar_local.sh`. O instalador cria o banco se necessário e, quando o schema já existe, preserva as tabelas e os dados; ele não importa novamente o SQL destrutivo. O `seed-demo.sql` é carregado por padrão. Para instalar somente a estrutura/usuário sem dados demonstrativos, use `FEIRA_SEED_DEMO=0 ./instalar_local.sh`. A recriação destrutiva só ocorre quando for explicitamente solicitado com `FEIRA_RECREATE_SCHEMA=1`.

O seed local cria o acesso `professor@etecmcm.sp.gov.br`, matrícula `DEMO2026` e senha `Feira@2026`, além de um projeto e quatro critérios para validação. Esses registros são apenas dados iniciais de teste e podem ser removidos sem alterar o schema.

## Correções realizadas

O login passou a usar os campos do frontend, valida a matrícula e a senha com `password_verify`, regenera a sessão e redireciona para o dashboard. As páginas do professor agora exigem autenticação, usam CSRF nos formulários de alteração e mantêm os dados na sessão apenas para a identidade autenticada.

Dashboard, trabalhos, popups, perfil e avaliação passaram a consultar e persistir dados nas tabelas `professor`, `projeto`, `aluno`, `stands`, `criterio` e `avaliacao`. A avaliação usa `INSERT ... ON DUPLICATE KEY UPDATE` na chave única já existente e atualiza a média do projeto sem modificar a estrutura do banco.

Também foram corrigidas as rotas legadas que apontavam para a tabela inexistente `professores`, o login legado foi encaminhado para o fluxo único, e a rota antiga de notas deixou de depender de uma configuração inexistente. O painel administrativo continua em PHP, usa as tabelas reais por meio do modelo `Professor`, mantém cadastro/edição/exclusão com CSRF e foi visualmente alinhado ao CSS administrativo sem emojis nem CSS inline.

## Validação

Foi executado `php -l` em todos os arquivos PHP, `node --check` no JavaScript, `bash -n` no instalador, verificação de assets/links locais e teste HTTP com MariaDB ativo. O login real retornou 302 e as páginas autenticadas retornaram 200. O instalador foi testado duas vezes com o schema existente e manteve as contagens de registros. O arquivo `FeiraBD.sql` não foi alterado; a recriação da estrutura só é usada mediante a variável explícita de recriação.
