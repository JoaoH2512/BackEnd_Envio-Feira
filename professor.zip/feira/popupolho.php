<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
$professor=exigirProfessor();
require_once __DIR__ . '/conexao.php';
$id=(int)($_GET['projeto']??0);
$stmt=$pdo->prepare('SELECT p.id,p.nome,p.descricao,p.status,p.nota,a.curso,a.turma,s.num_stand AS estande FROM projeto p LEFT JOIN aluno a ON a.id=p.id_aluno LEFT JOIN stands s ON s.fk_projeto=p.id WHERE p.id=:id AND p.orientador_id=:professor_id LIMIT 1'); $stmt->execute(['id'=>$id,'professor_id'=>$professor['id']]); $p=$stmt->fetch();
if(!$p){http_response_code(404);exit('Projeto não encontrado.');} $st=statusProjeto((string)$p['status'],$p['nota']===null?null:(float)$p['nota']);
?><!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title><?=e($p['nome'])?> - Detalhes</title><link rel="stylesheet" href="style.css"></head><body><main class="popup-page"><a class="modal-backdrop" href="dashboard.php" aria-label="Fechar detalhes"></a><section class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="project-modal-title"><a class="modal-close" href="dashboard.php" aria-label="Fechar">×</a><div class="modal-heading"><span class="modal-icon">▣</span><h1 id="project-modal-title"><?=e($p['nome'])?></h1></div><dl class="modal-info"><dt>Curso:</dt><dd><?=e($p['curso']??'—')?></dd><dt>Turma:</dt><dd><?=e($p['turma']??'—')?></dd><dt>Estande:</dt><dd><?=e($p['estande']??'—')?></dd><dt>Status:</dt><dd><span class="status <?=e($st['class'])?>"><?=e($st['label'])?></span></dd></dl><p class="modal-copy"><strong>Descrição:</strong><br><?=e($p['descricao']??'Sem descrição cadastrada.')?></p><a class="compact-button" href="avaliacao.php?projeto=<?=(int)$p['id']?>">Abrir avaliação</a></section></main></body></html>
