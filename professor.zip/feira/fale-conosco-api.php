<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/auth.php';
$professor = professorAtual();

if (!$professor || empty($professor['id'])) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'erro' => 'Usuário não autenticado.'], JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/conexao.php';
require_once __DIR__ . '/PainelADM/lib/models/Chat.php';

function responderChat(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $chat = new Chat($pdo);
    $professorId = (int) $professor['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $conversa = $chat->buscarConversaDoProfessor($professorId);
        if (!$conversa) {
            responderChat(['sucesso' => true, 'conversa_id' => null, 'mensagens' => []]);
        }

        $conversaId = (int) $conversa['id'];
        $solicitada = filter_input(INPUT_GET, 'conversa_id', FILTER_VALIDATE_INT);
        if ($solicitada && (int) $solicitada !== $conversaId) {
            responderChat(['sucesso' => false, 'erro' => 'Acesso negado.'], 403);
        }

        $chat->marcarRecebidas($conversaId, 'professor');
        responderChat([
            'sucesso' => true,
            'conversa_id' => $conversaId,
            'mensagens' => $chat->buscarMensagens($conversaId),
        ]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        responderChat(['sucesso' => false, 'erro' => 'Método não permitido.'], 405);
    }

    validarCsrf($_POST['csrf_token'] ?? null);
    $mensagem = trim((string) ($_POST['mensagem'] ?? ''));
    if ($mensagem === '') {
        responderChat(['sucesso' => false, 'erro' => 'Digite uma mensagem.'], 422);
    }
    if (mb_strlen($mensagem) > 2000) {
        responderChat(['sucesso' => false, 'erro' => 'A mensagem deve ter no máximo 2000 caracteres.'], 422);
    }

    $conversa = $chat->buscarConversaDoProfessor($professorId);
    $conversaId = $conversa ? (int) $conversa['id'] : $chat->criarOuBuscarConversa($professorId);
    $enviada = $chat->enviarMensagem($conversaId, 'professor', $professorId, $mensagem);

    responderChat([
        'sucesso' => true,
        'mensagem_id' => $enviada,
        'conversa_id' => $conversaId,
    ]);
} catch (Throwable $e) {
    error_log('Falha no canal Fale Conosco: ' . $e->getMessage());
    responderChat(['sucesso' => false, 'erro' => 'Não foi possível processar sua mensagem agora.'], 500);
}
