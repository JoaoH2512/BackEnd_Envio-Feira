<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
$professor = exigirProfessor();
require_once __DIR__ . '/conexao.php';
$mensagem = '';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validarCsrf($_POST['csrf_token'] ?? null);
    $nome = trim((string) ($_POST['nome'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Informe um nome e um e-mail válidos.';
    } else {
        try {
            $stmt = $pdo->prepare('UPDATE professor SET nome = :nome, email = :email WHERE id = :id');
            $stmt->execute(['nome' => $nome, 'email' => $email, 'id' => $professor['id']]);
            $_SESSION['professor']['nome'] = $nome;
            $_SESSION['professor']['email'] = $email;
            $professor = professorAtual();
            $mensagem = 'Alterações salvas com sucesso.';
        } catch (PDOException $e) {
            $erro = $e->errorInfo[1] === 1062 ? 'Este e-mail já está cadastrado.' : 'Não foi possível salvar as alterações.';
        }
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="theme-color" content="#7a0714"><title>Perfil | Feira Tecnológica</title><link rel="stylesheet" href="style.css"></head>
<body><main class="portal"><aside class="sidebar"><a class="brand-lockup" href="dashboard.php"><span class="brand-emblem">MCM</span><span class="brand-copy"><strong>Feira Tecnológica</strong><span>ETEC Maria Cristina Medeiros</span></span></a><p class="sidebar-label">Área do Professor</p><nav class="side-nav"><button type="button" data-page="dashboard.php">▣ Avaliações Gerais</button><button type="button" data-page="trabalhos.php">▤ Trabalhos Orientados</button><button type="button" data-page="avisos.php">♧ Avisos</button><button type="button" data-page="fale-conosco.php">✉ Fale conosco</button><button class="active" type="button" data-page="perfil.php">◯ Perfil</button></nav><p class="sidebar-footer">Feira Tecnológica · 2026</p></aside>
<section class="content-column"><header class="topbar"><div><p class="eyebrow">ÁREA DO PROFESSOR</p><h1>Meu Perfil</h1><p>Gerencie suas informações pessoais.</p></div><button class="notification-button" type="button" data-notification="Sem novos avisos." aria-label="Ver avisos">♧</button></header>
<section class="profile-card"><span class="profile-avatar"><?= e(strtoupper(substr($professor['nome'], 0, 1) . substr((string) strrchr(' ' . $professor['nome'], ' '), 1, 1))) ?></span><div><h2><?= e($professor['nome']) ?></h2><p><?= e($professor['email']) ?></p><p>Professor — ETEC Maria Cristina Medeiros</p></div></section>
<section class="form-card"><h3>Editar Informações</h3><?php if ($mensagem): ?><p id="form-status" role="status"><?= e($mensagem) ?></p><?php endif; ?><?php if ($erro): ?><p class="login-error" role="alert"><?= e($erro) ?></p><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>"><div class="form-grid"><div class="form-group"><label for="name">Nome completo</label><input id="name" name="nome" value="<?= e($professor['nome']) ?>" required></div><div class="form-group"><label for="email">E-mail</label><input id="email" name="email" type="email" value="<?= e($professor['email']) ?>" required></div></div><div class="form-actions"><button class="compact-button" type="submit">Salvar Alterações</button><a class="secondary-button" href="perfil.php">Cancelar</a></div></form></section></section><nav class="mobile-nav"><button type="button" data-page="dashboard.php">▣<span>Avaliações</span></button><button type="button" data-page="trabalhos.php">▤<span>Orientados</span></button><button type="button" data-page="avisos.php">♧<span>Avisos</span></button><button type="button" data-page="fale-conosco.php">✉<span>Contato</span></button><button class="active" type="button" data-page="perfil.php">◯<span>Perfil</span></button></nav></main><script src="script.js"></script></body></html>
