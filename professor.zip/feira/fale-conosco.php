<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
$professor = exigirProfessor();

require_once __DIR__ . '/conexao.php';
require_once __DIR__ . '/PainelADM/lib/models/Chat.php';

$chat = new Chat($pdo);
$conversa = $chat->buscarConversaDoProfessor((int) $professor['id']);
$conversaId = $conversa ? (int) $conversa['id'] : null;
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#7a0714">
  <meta name="description" content="Entre em contato com a administração da Feira Tecnológica.">
  <title>Fale Conosco | Feira Tecnológica</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="contact-styles.css">
</head>
<body data-page="fale-conosco">
  <main class="portal">
    <aside class="sidebar" aria-label="Navegação da área do professor">
      <a class="brand-lockup" href="dashboard.php" aria-label="Feira Tecnológica — página inicial">
        <span class="brand-emblem">MCM</span>
        <span class="brand-copy"><strong>Feira Tecnológica</strong><span>ETEC Maria Cristina Medeiros</span></span>
      </a>
      <p class="sidebar-label">Área do Professor</p>
      <nav class="side-nav" aria-label="Navegação principal">
        <button type="button" data-page="dashboard.php">▣ Avaliações Gerais</button>
        <button type="button" data-page="trabalhos.php">▤ Trabalhos Orientados</button>
        <button type="button" data-page="avisos.php">♧ Avisos</button>
        <button class="active" type="button" data-page="fale-conosco.php">✉ Fale conosco</button>
        <button type="button" data-page="perfil.php">◯ Perfil</button>
      </nav>
      <p class="sidebar-footer">Feira Tecnológica · 2026</p>
    </aside>

    <section class="content-column">
      <header class="topbar">
        <div>
          <p class="eyebrow">COMUNICAÇÃO</p>
          <h1>Fale conosco</h1>
          <p>Envie dúvidas, sugestões ou informações para a administração.</p>
        </div>
      </header>

      <section class="contact-layout" aria-label="Fale conosco">
        <article class="contact-info-card">
          <span class="contact-icon" aria-hidden="true">✉</span>
          <p class="contact-kicker">ATENDIMENTO INSTITUCIONAL</p>
          <h2>Estamos aqui para ajudar</h2>
          <p class="contact-description">Use este canal para falar diretamente com a administração da Feira Tecnológica. Sua mensagem ficará registrada nesta conversa para facilitar o acompanhamento.</p>
          <div class="contact-topics">
            <p>Você pode falar sobre:</p>
            <button type="button" class="topic-chip" data-message="Tenho uma dúvida sobre uma avaliação.">Avaliações</button>
            <button type="button" class="topic-chip" data-message="Preciso de orientação sobre um projeto.">Projetos orientados</button>
            <button type="button" class="topic-chip" data-message="Gostaria de enviar uma sugestão.">Sugestões</button>
          </div>
        </article>

        <article class="contact-chat-card" data-chat data-conversa-id="<?= $conversaId ?? '' ?>" data-csrf="<?= e(csrfToken()) ?>">
          <header class="contact-chat-header">
            <span class="contact-avatar" aria-hidden="true">ADM</span>
            <div>
              <h2>Administração</h2>
              <p>Canal de atendimento da Feira Tecnológica</p>
            </div>
            <span class="contact-status"><i></i> Canal seguro</span>
          </header>

          <div id="contact-messages" class="contact-messages" aria-live="polite" aria-label="Mensagens da conversa">
            <div class="contact-empty" data-empty-state>
              <span aria-hidden="true">✦</span>
              <h3>Comece uma conversa</h3>
              <p>Envie sua primeira mensagem para a administração.</p>
            </div>
          </div>

          <form id="contact-form" class="contact-form">
            <label class="screen-reader-only" for="contact-input">Mensagem para a administração</label>
            <textarea id="contact-input" maxlength="2000" rows="2" placeholder="Escreva sua mensagem..." required></textarea>
            <div class="contact-form-footer">
              <span id="contact-counter">0/2000</span>
              <button type="submit" class="compact-button"><span>Enviar mensagem</span><span aria-hidden="true">→</span></button>
            </div>
          </form>
          <p id="contact-status" class="contact-form-status" role="status" aria-live="polite"></p>
        </article>
      </section>
    </section>

    <nav class="mobile-nav" aria-label="Navegação móvel">
      <button type="button" data-page="dashboard.php">▣<span>Avaliações</span></button>
      <button type="button" data-page="trabalhos.php">▤<span>Orientados</span></button>
      <button type="button" data-page="avisos.php">♧<span>Avisos</span></button>
      <button class="active" type="button" data-page="fale-conosco.php">✉<span>Contato</span></button>
      <button type="button" data-page="perfil.php">◯<span>Perfil</span></button>
    </nav>
  </main>

  <script src="script.js"></script>
  <script>
    (function () {
      'use strict';

      var card = document.querySelector('[data-chat]');
      var messages = document.getElementById('contact-messages');
      var form = document.getElementById('contact-form');
      var input = document.getElementById('contact-input');
      var counter = document.getElementById('contact-counter');
      var status = document.getElementById('contact-status');
      var conversaId = card.dataset.conversaId || '';
      var csrfToken = card.dataset.csrf;
      var loading = false;

      function escapeHtml(value) {
        var element = document.createElement('div');
        element.textContent = value;
        return element.innerHTML;
      }

      function formatTime(value) {
        var date = new Date(String(value || '').replace(' ', 'T'));
        return Number.isNaN(date.getTime()) ? '' : date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      }

      function showStatus(message, isError) {
        status.textContent = message || '';
        status.classList.toggle('error', Boolean(isError));
      }

      function renderMessages(items) {
        if (!items.length) {
          messages.innerHTML = '<div class="contact-empty" data-empty-state><span aria-hidden="true">✦</span><h3>Comece uma conversa</h3><p>Envie sua primeira mensagem para a administração.</p></div>';
          return;
        }

        messages.innerHTML = items.map(function (item) {
          var own = item.remetente_tipo === 'professor';
          var checks = own ? '<span class="contact-checks" aria-label="Mensagem enviada">' + (item.status === 'enviada' ? '✓' : '✓✓') + '</span>' : '';
          return '<div class="contact-message ' + (own ? 'is-own' : 'is-admin') + '"><div class="contact-bubble">' +
            '<p>' + escapeHtml(item.mensagem) + '</p><span>' + formatTime(item.criado_em) + checks + '</span></div></div>';
        }).join('');
        messages.scrollTop = messages.scrollHeight;
      }

      async function loadMessages() {
        if (loading) return;
        loading = true;
        try {
          var query = conversaId ? '?conversa_id=' + encodeURIComponent(conversaId) : '';
          var response = await fetch('fale-conosco-api.php' + query, { cache: 'no-store' });
          var data = await response.json();
          if (!response.ok || !data.sucesso) throw new Error(data.erro || 'Não foi possível carregar a conversa.');
          if (data.conversa_id) {
            conversaId = String(data.conversa_id);
            card.dataset.conversaId = conversaId;
          }
          renderMessages(data.mensagens || []);
        } catch (error) {
          if (!messages.querySelector('.contact-message')) showStatus(error.message, true);
        } finally {
          loading = false;
        }
      }

      async function sendMessage(message) {
        var formData = new FormData();
        formData.append('mensagem', message);
        formData.append('csrf_token', csrfToken);
        if (conversaId) formData.append('conversa_id', conversaId);

        var response = await fetch('fale-conosco-api.php', { method: 'POST', body: formData });
        var data = await response.json();
        if (!response.ok || !data.sucesso) throw new Error(data.erro || 'Não foi possível enviar a mensagem.');
        conversaId = String(data.conversa_id);
        card.dataset.conversaId = conversaId;
        input.value = '';
        updateCounter();
        showStatus('Mensagem enviada.', false);
        await loadMessages();
      }

      function updateCounter() {
        counter.textContent = input.value.length + '/2000';
      }

      input.addEventListener('input', updateCounter);
      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        var message = input.value.trim();
        if (!message) return;
        var button = form.querySelector('button[type="submit"]');
        button.disabled = true;
        showStatus('Enviando...', false);
        try {
          await sendMessage(message);
        } catch (error) {
          showStatus(error.message, true);
        } finally {
          button.disabled = false;
        }
      });

      input.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && !event.shiftKey) {
          event.preventDefault();
          form.requestSubmit();
        }
      });

      document.querySelectorAll('[data-message]').forEach(function (button) {
        button.addEventListener('click', function () {
          input.value = button.dataset.message || '';
          updateCounter();
          input.focus();
        });
      });

      updateCounter();
      loadMessages();
      window.setInterval(loadMessages, 4000);
    }());
  </script>
</body>
</html>
