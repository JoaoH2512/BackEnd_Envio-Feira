<?php
$redirect = (string) ($_GET['redirect'] ?? '');
header('Location: ../login.php' . ($redirect !== '' ? '?redirect=' . urlencode($redirect) : ''));
exit;
?>
