<?php
declare(strict_types=1);

require_once __DIR__ . '/../conexao.php';
require_once __DIR__ . '/../auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit;
}

$email = trim((string) ($_POST['email'] ?? ''));
$matricula = trim((string) ($_POST['matricula'] ?? $_POST['registration'] ?? ''));
$senha = (string) ($_POST['senha'] ?? $_POST['password'] ?? '');
$redirect = (string) ($_POST['redirect'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $matricula === '' || $senha === '') {
    header('Location: ../login.php?erro=credenciais&redirect=' . urlencode($redirect));
    exit;
}

$stmt = $pdo->prepare('SELECT id, nome, email, senha, matricula, tipo FROM professor WHERE email = :email AND matricula = :matricula LIMIT 1');
$stmt->execute(['email' => $email, 'matricula' => $matricula]);
$usuario = $stmt->fetch();

if (!$usuario || !password_verify($senha, (string) $usuario['senha'])) {
    header('Location: ../login.php?erro=credenciais&redirect=' . urlencode($redirect));
    exit;
}

session_regenerate_id(true);
$_SESSION['professor'] = [
    'id' => (int) $usuario['id'],
    'nome' => $usuario['nome'],
    'email' => $usuario['email'],
    'matricula' => $usuario['matricula'],
    'tipo' => $usuario['tipo'],
];
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

if (password_needs_rehash((string) $usuario['senha'], PASSWORD_DEFAULT)) {
    $novoHash = password_hash($senha, PASSWORD_DEFAULT);
    $update = $pdo->prepare('UPDATE professor SET senha = :senha WHERE id = :id');
    $update->execute(['senha' => $novoHash, 'id' => $usuario['id']]);
}

$destino = $redirect !== '' && !preg_match('#^(?:https?:)?//#i', $redirect) ? $redirect : '../dashboard.php';
header('Location: ' . $destino);
exit;
?>
