USE feirabd;

INSERT INTO professor (nome, email, senha, matricula, tipo)
VALUES ('Professor Demonstração', 'professor@etecmcm.sp.gov.br', '$2y$10$FttuUmcT55ktjk1eQtp.S.0en/r3863aY4Y7TfJMIghOro9jdYMt.', 'DEMO2026', 'orientador')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), senha = VALUES(senha), tipo = VALUES(tipo);

INSERT INTO aluno (rm, nome, email, senha_hash, curso, turma, tipo)
VALUES ('RM-DEMO-01', 'Aluno Demonstração', 'aluno.demo@etecmcm.sp.gov.br', '$2y$10$FttuUmcT55ktjk1eQtp.S.0en/r3863aY4Y7TfJMIghOro9jdYMt.', 'Informática para Internet', '3º', 'lider')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), curso = VALUES(curso), turma = VALUES(turma);

INSERT INTO criterio (nome)
SELECT 'Inovação e originalidade' WHERE NOT EXISTS (SELECT 1 FROM criterio WHERE nome = 'Inovação e originalidade');
INSERT INTO criterio (nome)
SELECT 'Viabilidade técnica' WHERE NOT EXISTS (SELECT 1 FROM criterio WHERE nome = 'Viabilidade técnica');
INSERT INTO criterio (nome)
SELECT 'Impacto e sustentabilidade' WHERE NOT EXISTS (SELECT 1 FROM criterio WHERE nome = 'Impacto e sustentabilidade');
INSERT INTO criterio (nome)
SELECT 'Apresentação e domínio do tema' WHERE NOT EXISTS (SELECT 1 FROM criterio WHERE nome = 'Apresentação e domínio do tema');

INSERT INTO projeto (nome, descricao, periodo, orientador_id, status, id_aluno)
SELECT 'Projeto Demonstração', 'Projeto criado para validar o fluxo integrado do backend.', 'matutino', p.id, 'pendente', a.id
FROM professor p CROSS JOIN aluno a
WHERE p.email = 'professor@etecmcm.sp.gov.br' AND a.rm = 'RM-DEMO-01'
  AND NOT EXISTS (SELECT 1 FROM projeto WHERE nome = 'Projeto Demonstração');

INSERT INTO stands (sala, num_stand, fk_projeto)
SELECT 'Sala Demo', 'D-01', p.id
FROM projeto p
WHERE p.nome = 'Projeto Demonstração'
  AND NOT EXISTS (SELECT 1 FROM stands WHERE fk_projeto = p.id);
